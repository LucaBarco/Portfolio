#include <string.h>

/* lib_adc.c */
void DAC_init (void);
void DAC_convert (int value);

