/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../led/led.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int down=0;

void RIT_IRQHandler (void)
{					
	static int select=0;
	static int i=0;	
	static int leds=0; // contiente il vettore dei led da accendere o spegnere
	
	//	alto 			29
	//	basso 		26
	// 	sinistra 	27
	//	desta 		28
	// 	premuto 	25
	
	
	if(((LPC_GPIO1->FIOPIN & (31<<25)) ^ (31<<25)) !=0 ){		//controllo che almeno uno input del joystick sia attivo 
																													// con la and estraiamo i 5 bit corrispondent agli input
																													// con la xor verifichiamo che almeno uno sia attivo (ovvero il bit � a 0)
		select++;				// serve per l'intermittenza 
				
		if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){	//pressione pulsante
			
			switch(select){
				case 1:
				if(i%2==0)
					leds=0x80;
				else
					leds=0x01;
				i++;
				break;
				default:
				break;
			}
		} if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	//basso
				leds|=0x30;
		}if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	//alto
				leds|=0x0C;
		}if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	//destra
				leds|=0x03;
		}if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	//sinistra
				leds|=0xC0;
		}
			LED_Out(leds);
	}
	else {		//resetto tutto se non � selezionato nulla	
			select=0;
			leds=0;	
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
